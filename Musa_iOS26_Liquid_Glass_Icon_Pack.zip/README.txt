MUSA — LIQUID GLASS INSPIRED ICON SET
======================================

Contents
- 39 individual 512x512 PNG icons in /icons
- Preview.png contact sheet

Style
- Glossy translucent glass-inspired tiles
- Consistent rounded-square shape, reflections and highlights
- App marks are simplified interpretations, not official brand artwork

Important compatibility note
Realme UI 7.0's built-in Icons screen in the supplied screenshot shows built-in styles,
ART+ Icons, and icon sizing, but no direct third-party icon-pack import option.
These PNGs are therefore supplied as individual assets. They may be applied through
a shortcut customization app that supports custom PNG icons. Shortcut icons can behave
differently from native launcher icons and may not replace every system/app-drawer icon.

To use
1. Extract this ZIP.
2. Open a shortcut customization app that supports custom image icons.
3. Choose an app shortcut, select its PNG from the icons folder, and save it.
4. Repeat for the apps you want on your home screen.

This is a fan-made visual theme inspired by iOS Liquid Glass, not an official Apple product.
